import asyncio
import random
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        # Launch browser
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        try:
            # Navigate to login page
            await page.goto('https://portal.terraacademyforarts.com/users/sign_in')
            
            # Fill login form
            await page.fill('input[name="user[email]"]', 'tefta3@haren.uk')
            await page.fill('input[name="user[password]"]', '_Danmadam1')
            
            # Click login button
            await page.click('.button.button-primary.g-recaptcha')
            
            # Wait for login to complete
            await page.wait_for_selector('.card__resume')
            
            # Click resume button
            await page.click('.card__resume')
            
            # Initial sequence of clicks
            await page.wait_for_selector('[data-qa="complete-continue__btn"]')
            await page.click('[data-qa="complete-continue__btn"]')
            await asyncio.sleep(3)
            await page.click('[data-qa="complete-continue__btn"]')
            
            # Wait for choice to be visible and click it
            await page.wait_for_selector('#choice-20163910')
            await page.click('#choice-20163910')
            await page.click('._button--default_142a8m')
            await page.click('.brand-color__background.brand-color__dynamic-text._button--default_142a8m._button--icon-right_142a8m')
            
            # Multiple continue clicks with waits
            for _ in range(20):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Click small default button
            await page.click('._button--default--small_142a8m')
            
            # More continue clicks
            for _ in range(8):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Click another small default button
            await page.click('._button--default--small_142a8m')
            
            # Even more continue clicks
            for _ in range(4):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Series of choice confirmations
            choices = [
                "choice-101782895", "choice-101782897", "choice-101782904",
                "choice-101782908", "choice-101782911", "choice-101782914",
                "choice-101782919", "choice-101782921", "choice-101782926",
                "choice-101782931"
            ]
            
            for choice in choices:
                await page.click(f'#{choice}')
                await page.click('text=Confirm')
                await asyncio.sleep(2)
                await page.click('text=Next')
            
            # Click brand color button
            await page.click('.brand-color__background.brand-color__dynamic-text._button--default_142a8m._button--icon-right_142a8m')
            
            # More continue clicks
            for _ in range(8):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Click small default button
            await page.click('._button--default--small_142a8m')
            
            # More continue clicks
            for _ in range(8):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Click another small default button
            await page.click('._button--default--small_142a8m')
            
            # More continue clicks
            for _ in range(4):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Click small default button
            await page.click('._button--default--small_142a8m')
            
            # More continue clicks
            for _ in range(4):
                await page.click('[data-qa="complete-continue__btn"]')
                await asyncio.sleep(3)
            
            # Scale selection
            await page.click('#scale-20164041')
            await page.click('._button--default_142a8m')
            
            # Fill textarea
            await page.fill('#ember1026', 'Great and I look forward to using the skills i learnt in a real world scenario')
            await page.click('._button--default_142a8m')
            
            # Click specific element by XPath
            await page.click('//*[@id="ember1004"]/div/div[1]/div/div[10]/span/div/p')
            await page.click('._button--default_142a8m')
            await page.click('.brand-color__background.brand-color__dynamic-text._button--default_142a8m._button--icon-right_142a8m')
            
            # Wait and make choice
            await asyncio.sleep(2)
            await page.click('#choice-20164054')
            await page.click('._button--default_142a8m')
            
            # Generate random phone number
            prefixes = ['080', '070', '090', '081', '091']
            prefix = random.choice(prefixes)
            remaining = ''.join([str(random.randint(0, 9)) for _ in range(8)])
            phone_number = prefix + remaining
            
            # Fill phone number
            await page.fill('#ember1097', phone_number)
            await page.click('._button--default_142a8m')
            
            # Wait and make more choices
            await asyncio.sleep(2)
            await page.click('[aria-labelledby="choice-20164055"]')
            await page.click('._button--default_142a8m')
            
            await asyncio.sleep(2)
            await page.click('#choice-20164060')
            await page.click('._button--default_142a8m')
            
            # Click to open new tab
            await asyncio.sleep(2)
            await page.click('#ember1126')
            
            # Wait for new tab and take screenshot
            async with context.expect_page() as new_page_info:
                new_page = await new_page_info.value
                await new_page.wait_for_load_state()
                await new_page.screenshot(path='certificate.png')
                
                # Download PDF
                async with new_page.expect_download() as download_info:
                    await new_page.click('#download-pdf')
                download = await download_info.value
                await download.save_as('certificate.pdf')
            
        except Exception as e:
            print(f"An error occurred: {e}")
        finally:
            # Close browser
            await browser.close()

asyncio.run(main())
