import requests
import time

# Ask the user how many mails they want
num_mails = int(input("How many emails do you want to generate? "))

# Define the base URL
base_url = "https://m.kuku.lu/index.php"

# Initialize the dynamic value for "_"
underscore_value = 1743557479182

# Loop through the number of emails requested
for i in range(1, num_mails + 1):
    new_user = f"tefta{i}"
    
    # Define query parameters
    params = {
        "action": "addMailAddrByManual",
        "nopost": "1",
        "by_system": "1",
        "t": "1743557464",
        "csrf_token_check": "2a47d239fd7e3fcc010e91acb341e7c3",
        "newdomain": "haren.uk",
        "newuser": new_user,
        "recaptcha_token": "",
        "_": str(underscore_value)
    }

    # Define headers
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://m.kuku.lu/",
        "Sec-Ch-Ua": '"Microsoft Edge";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
        "X-Requested-With": "XMLHttpRequest"
    }

    # Define cookies
    cookies = {
        "cookie_csrf_token": "2a47d239fd7e3fcc010e91acb341e7c3",
        "cookie_sessionhash": "SHASH%3A67d9a1044290a8ba51529d28b04c879e",
        "cookie_gendomainorder": "haren.uk",
    }

    # Send the GET request
    response = requests.get(base_url, headers=headers, cookies=cookies, params=params)

    # Print response details
    print(f"Generated Email: {new_user}@haren.uk")
    print(f"Status Code: {response.status_code}")
    print("Response Headers:", response.headers)
    print("Response Content:", response.text)
    print("-" * 50)
    
    # Increment the underscore value by 3
    underscore_value += 3
    
    # Wait for 3 seconds before the next request
    time.sleep(1)
