import random 
import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import time

# Lists of 50 male and 50 female names from Kano, Nigeria (Muslims)
male_names = [
    "Ahmed", "Mohammed", "Yusuf", "Abdullahi", "Hassan", "Usman", "Kabir", "Ibrahim", "Suleiman", "Musa",
    "Aliyu", "Bashir", "Haruna", "Jibril", "Mustapha", "Umar", "Tijjani", "Salisu", "Nuhu", "Sa'id",
    "Abubakar", "Ismail", "Nasiru", "Shehu", "Bello", "Garba", "Mahmud", "Zubairu", "Sani", "Tukur",
    "Aminu", "Khalid", "Faruq", "Habib", "Lukman", "Danjuma", "Rabiu", "Shamsudeen", "Yahaya", "Ilyasu",
    "Hafiz", "Zakari", "Hamisu", "Murtala", "Adamu", "Samaila", "Abdulkarim", "Abdulmalik", "Abdulkadir", "Idris"
]

female_names = [
    "Aisha", "Fatima", "Zainab", "Hafsat", "Maryam", "Khadija", "Rukayya", "Sadiya", "Asiya", "Jummai",
    "Halima", "Safiya", "Bilqis", "Nafisa", "Rahma", "Binta", "Jamila", "Maimuna", "Hadiza", "Lubna",
    "Hajara", "Munira", "Sa'adatu", "Rabi", "Sumayya", "Ummi", "Lami", "Sakina", "Husseina", "Amina",
    "Ramatu", "Gimbiya", "Tani", "Laila", "Firdous", "Zulaihat", "Firdausi", "Halimatu", "Baraka", "Suhaila",
    "Nasiba", "Aminatu", "Areefa", "Shafa'atu", "Tasleem", "Mubina", "Jannatu", "Farida", "Zahara", "Sultana"
]

# List of cities and streets in Kano
kano_cities = {
    "Dala": [
        "Kofar Mazugal Road, Dala", "Jakara Street, Dala", "Kurmi Market Road, Dala", "Shekarau Street, Dala", 
        "Kofar Ruwa Road, Dala", "Bakin Ruwa Street, Dala", "Yan Katako Street, Dala", "Wambai Market Street, Dala", 
        "Sabon Titi, Dala", "Kofar Dawanau Road, Dala"
    ],
    "Fagge": [
        "Abubakar Rimi Market Road, Fagge", "Murtala Mohammed Way, Fagge", "France Road, Fagge", "IBB Road, Fagge", 
        "Kantin Kwari Market Street, Fagge", "Sani Abacha Way, Fagge", "Zungeru Road, Fagge", "Kwari Textile Market Street, Fagge", 
        "Matan Fada Road, Fagge", "Ibrahim Taiwo Road, Fagge"
    ],
    "Kano Municipal": [
        "Zoo Road, Kano Municipal", "Emir's Palace Road, Kano Municipal", "BUK Road, Kano Municipal", "Kabuga Road, Kano Municipal", 
        "Ahmadu Bello Way, Kano Municipal", "State Road, Kano Municipal", "Gidan Murtala Road, Kano Municipal", "Sabon Gari Road, Kano Municipal", 
        "Gyadi-Gyadi Road, Kano Municipal", "Gandun Albasa Road, Kano Municipal"
    ],
}

# Initialize exports list
exports = []

def save_to_exports():
    with open('exports.py', 'w') as f:
        f.write(f"exports = {exports}")

def submit_form(email_counter):
    first_name = random.choice(female_names)
    last_name = random.choice(male_names)
    date_of_birth = (datetime.now() - timedelta(days=random.randint(21*365, 25*365))).strftime("%m/%d/%Y")
    phone_number = random.choice(["080", "070", "090", "081", "091"]) + "".join(str(random.randint(0, 9)) for _ in range(8))
    city = random.choice(list(kano_cities.keys()))
    address = random.choice(kano_cities[city])
    email = f"tefta{email_counter}@haren.uk"
    gender = "two"

    # Save data to exports list
    exports.append({
        'first_name': first_name,
        'last_name': last_name,
        'gender': gender,
        'email': email,
        'phone_number': phone_number,
        'city': city
    })

    # Initialize a session to maintain cookies
    session = requests.Session()
    
    # Step 1: Fetch the form page to extract dynamic values
    form_url = "https://terraacademyforarts.com/form-art-business/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
        "Referer": form_url,
    }

    try:
        # Initial GET request to get cookies and form data
        response = session.get(form_url, headers=headers, timeout=10)
        response.raise_for_status()
        
        # Print initial cookies if any
        print(f"Initial cookies for submission {email_counter}:")
        for cookie in session.cookies:
            print(f"{cookie.name}: {cookie.value}")
        
        soup = BeautifulSoup(response.text, 'html.parser')
        nonce_input = soup.find("input", {"name": "forminator_nonce"})
        forminator_nonce = nonce_input.get("value") if nonce_input else ""
        form_id_input = soup.find("input", {"name": "form_id"})
        form_id = form_id_input.get("value") if form_id_input else "30582"
        page_id_input = soup.find("input", {"name": "page_id"})
        page_id = page_id_input.get("value") if page_id_input else "30582"
        render_id = "0"

        # Step 2: Submit the form with dynamic values
        submit_url = "https://terraacademyforarts.com/wp-admin/admin-ajax.php"
        payload = {
            "name-1-first-name": first_name,
            "name-1-middle-name": "",
            "name-1-last-name": last_name,
            "select-1": gender,
            "select-2": "two",
            "date-1": date_of_birth,
            "select-3": "None",
            "email-1": email,
            "select-4": "one",
            "address-1-street_address": address,
            "address-1-address_line": "",
            "address-1-city": city,
            "phone-1": phone_number,
            "phone-2": "",
            "text-2": city,
            "select-5": "one",
            "select-6": "two",
            "select-8": "Information-not-available",
            "select-9": "Information-not-available",
            "select-10": "Information-not-available",
            "radio-1": "two",
            "text-3": "",
            "select-12": "",
            "select-13": "",
            "textarea-1": "",
            "phone-3": "",
            "phone-4": "",
            "email-2": "",
            "text-4": "",
            "text-5": "",
            "text-6": "",
            "select-11": "Friends-Family-Colleague",
            "select-14": "YERKS KANO 1",
            "referer_url": "",
            "forminator_nonce": forminator_nonce,
            "_wp_http_referer": "/form-script-writing/",
            "form_id": form_id,
            "page_id": page_id,
            "form_type": "default",
            "current_url": form_url,
            "render_id": render_id,
            "action": "forminator_submit_form_custom-forms"
        }

        submit_headers = {**headers, "Content-Type": "application/x-www-form-urlencoded"}
        submit_response = session.post(submit_url, headers=submit_headers, data=payload, timeout=10)
        submit_response.raise_for_status()
        print(f"Form submission {email_counter} successful! Email: {email}")
        
        # Print cookies after submission
        print(f"Cookies after submission for {email}:")
        for cookie in session.cookies:
            print(f"{cookie.name}: {cookie.value}")
        
        # Save after each successful submission
        save_to_exports()
        
        # Add a small delay to avoid overwhelming the server
        time.sleep(random.uniform(1, 3))

    except requests.exceptions.RequestException as e:
        print(f"Request Error for email {email}: {e}")
    except Exception as e:
        print(f"Error for email {email}: {e}")

# Run the script 200 times
for i in range(1, 200):
    submit_form(i)
    print(f"Progress: {i}/196")

print("All submissions completed!")
print(f"Data saved to exports.py with {len(exports)} entries")
